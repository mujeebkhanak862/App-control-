package com.controlhub.app.accessibility;
import java.util.*;
public class ControlHubAccessibilityService {
  public static List<UiElement> SCREEN = new ArrayList<>();
  public static ControlHubAccessibilityService getInstance(){ return new ControlHubAccessibilityService(); }
  public List<UiElement> readUi(){ return new ArrayList<>(SCREEN); } }
