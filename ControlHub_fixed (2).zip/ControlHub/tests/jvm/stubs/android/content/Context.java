package android.content;
import java.util.*;
public class Context { public static final int MODE_PRIVATE=0; static final Map<String,Object> store=new HashMap<>();
 public Context getApplicationContext(){return this;}
 public SharedPreferences getSharedPreferences(String n,int m){ return new SharedPreferences(){
  public boolean getBoolean(String k,boolean d){ Object v=store.get(n+k); return v==null?d:(Boolean)v; }
  public String getString(String k,String d){ Object v=store.get(n+k); return v==null?d:(String)v; }
  public Editor edit(){ return new Editor(){ public Editor putBoolean(String k,boolean v){store.put(n+k,v);return this;} public Editor putString(String k,String v){store.put(n+k,v);return this;} public void apply(){} }; } }; } }
