# Control Hub

```
app/      Android app (Gradle root — settings.gradle isi folder mein hai)
backend/  Railway pe chalne wala relay + MCP server  (README wahin hai)
.github/  APK build workflow (GitHub Actions)
```

## APK banana (Android Studio ke bina)
1. Poora folder GitHub repo mein push karo
2. Repo → **Actions → Build Control Hub APK → Run workflow**
3. Build hone par run ke neeche **Artifacts → ControlHub-debug-apk** se APK download karo

Pehli build mein compile error aa sakta hai (is project ka code abhi kabhi compile nahi hua —
sirf static checks hue hain). Aisa ho to failed run ka error log copy karke bhej do.

## Aage
Backend + Claude connector: `backend/README.md`
