package com.controlhub.app.automation;

import com.controlhub.app.accessibility.UiElement;

import java.util.ArrayList;
import java.util.List;

/**
 * Ek "decided action" — Reason step (Feature #32) ka output, Act step (Feature #33) ka input.
 * Step 3: element/selector/confidence, post-conditions aur recovery flag saath aate hain.
 */
public class AutomationStep {

    public enum Type {
        TAP_ELEMENT, TAP_XY, TYPE_TEXT, SCROLL,
        LAUNCH_APP, STOP_APP, PRESS_BACK, PRESS_HOME, PRESS_KEY,
        WAIT,
        REPLY,   // Step 4: notification inline reply (Mode A)
        DONE,
        FAIL
    }

    public final Type type;
    public int elementId;
    public UiElement element;          // TAP_ELEMENT: resolve hua asli element
    public int x;
    public int y;
    public String text;
    public String direction;
    public String packageName;
    public String reason;              // debug/log ke liye
    public String selectorKind = "";   // audit: id/desc/text/hierarchy/xy
    public double confidence = 1.0;
    public String replyTarget;         // REPLY: contact/key
    public String notificationKey;     // REPLY: executor set karta hai (verify ke liye)
    public long notifPostTimeBefore;   // REPLY: bhejne se pehle notification ka postTime
    public int waitSeconds;            // WAIT
    public boolean longPress = false;  // Step 7: TAP_* ko long-press banata hai
    public boolean recovery = false;   // true = recovery action (scroll) — command aage nahi badhta
    public List<PostCondition> conditions = new ArrayList<>();

    public AutomationStep(Type type) {
        this.type = type;
    }

    public static AutomationStep tapMatch(Selector.Match m, String reason) {
        AutomationStep s;
        if (m.element != null) {
            s = new AutomationStep(Type.TAP_ELEMENT);
            s.element = m.element;
            s.elementId = m.element.elementId;
        } else {
            s = new AutomationStep(Type.TAP_XY);
            s.x = m.x;
            s.y = m.y;
        }
        s.selectorKind = m.selector.kind();
        s.confidence = m.confidence;
        s.reason = reason;
        return s;
    }

    public static AutomationStep typeText(String text, String reason) {
        AutomationStep s = new AutomationStep(Type.TYPE_TEXT);
        s.text = text;
        s.reason = reason;
        return s;
    }

    public static AutomationStep scroll(String direction, String reason) {
        AutomationStep s = new AutomationStep(Type.SCROLL);
        s.direction = direction;
        s.reason = reason;
        return s;
    }

    public static AutomationStep launchApp(String packageName, String reason) {
        AutomationStep s = new AutomationStep(Type.LAUNCH_APP);
        s.packageName = packageName;
        s.reason = reason;
        return s;
    }

    public static AutomationStep pressBack(String reason) {
        AutomationStep s = new AutomationStep(Type.PRESS_BACK);
        s.reason = reason;
        return s;
    }

    public static AutomationStep pressKey(String key, String reason) {
        AutomationStep s = new AutomationStep(Type.PRESS_KEY);
        s.text = key;
        s.reason = reason;
        return s;
    }

    public static AutomationStep pressHome(String reason) {
        AutomationStep s = new AutomationStep(Type.PRESS_HOME);
        s.reason = reason;
        return s;
    }

    public boolean isUi() {
        switch (type) {
            case TAP_ELEMENT: case TAP_XY: case TYPE_TEXT: case SCROLL:
            case LAUNCH_APP: case STOP_APP: case PRESS_BACK: case PRESS_HOME: case PRESS_KEY:
                return true;
            default:
                return false;
        }
    }

    public static AutomationStep done(String reason) {
        AutomationStep s = new AutomationStep(Type.DONE);
        s.reason = reason;
        return s;
    }

    public static AutomationStep fail(String reason) {
        AutomationStep s = new AutomationStep(Type.FAIL);
        s.reason = reason;
        return s;
    }
}
