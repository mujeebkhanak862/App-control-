package com.controlhub.app.automation;

/**
 * Step 3 — Ek command par recovery ki halat. Command aage badhte hi reset hota hai.
 *
 * Recovery ladder (tap ke liye):
 *   failure 0 : sabse behtar selector
 *   element nahi mila : screen scroll karke (max 2 baar) dobara dhoondo
 *   failure 1,2 : re-observe karke ALTERNATE selector / candidate
 *   failure 3 : escalate (task failed + "task.needs_attention" event)
 */
public class RecoveryContext {
    public int failuresOnStep = 0;
    public int scrollsTried = 0;

    public void reset() {
        failuresOnStep = 0;
        scrollsTried = 0;
    }
}
