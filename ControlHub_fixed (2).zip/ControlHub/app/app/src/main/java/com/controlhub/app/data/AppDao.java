package com.controlhub.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface AppDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsert(AppEntity app);

    @Query("SELECT * FROM apps ORDER BY appLabel ASC")
    List<AppEntity> getAll();

    @Query("SELECT * FROM apps WHERE packageName = :packageName LIMIT 1")
    AppEntity getByPackage(String packageName);
}
