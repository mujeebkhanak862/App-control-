package com.controlhub.app.filetransfer;

import android.content.Context;

import java.io.File;

/**
 * Feature #60/#61 — Android-side bridge. Poori chunking/pause/resume logic
 * (TransferManager) pure Java hai, isliye alag se test ho chuki hai — ye
 * class sirf app ka storage-folder de deti hai.
 *
 * outbox/         — Feature #60: yahan rakhi file hi "send" ki ja sakti hai
 *                    (poore phone storage ka arbitrary path allow nahi karte —
 *                    warna koi bhi private file leak ho sakti thi)
 * incoming_tmp/    — Feature #61: partial/in-progress incoming files
 * received_files/  — Feature #61: mukammal ho chuki incoming files
 */
public class FileTransferBridge {

    private static final int CHUNK_SIZE = 256 * 1024; // 256 KB — MCP/relay ke through JSON+base64 mein bhejne layak
    private static volatile TransferManager instance;

    public static TransferManager get(Context context) {
        if (instance == null) {
            synchronized (FileTransferBridge.class) {
                if (instance == null) {
                    instance = new TransferManager(context.getApplicationContext().getFilesDir(), CHUNK_SIZE);
                }
            }
        }
        return instance;
    }

    public static File outboxDir(Context context) {
        File dir = new File(context.getApplicationContext().getFilesDir(), "outbox");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    /** Feature #60 — sirf outbox/ ke andar ka naam allow karta hai (path traversal se bachne ke liye, Feature #61 wale sanitize jaisa hi) */
    public static File resolveOutboxFile(Context context, String fileName) {
        String safeName = new File(fileName == null ? "" : fileName.trim()).getName();
        if (safeName.isEmpty() || safeName.equals(".") || safeName.equals("..")) {
            throw new IllegalArgumentException("Invalid fileName");
        }
        return new File(outboxDir(context), safeName);
    }
}
