package com.controlhub.app.automation;

import com.controlhub.app.accessibility.UiElement;
import com.controlhub.app.notifications.NotificationStore;

import java.util.List;

/**
 * Feature #34 — Verify
 *
 * Step 3: sirf "screen badli?" nahi. Pehle command ke apne post-conditions (=> ...), warna har
 * action ke liye concrete default:
 *   LAUNCH_APP : foreground package == target
 *   TYPE_TEXT  : typed text screen par dikhna chahiye
 *   TAP        : screen (ya app) badli
 *   BACK       : screen badli
 *   HOME       : badli, ya pehle se home par (note ke saath pass)
 *   SCROLL     : badli; na badle to "content ka end" maana jata hai (note ke saath pass)
 * UI ko settle hone ka waqt dene ke liye poll karta hai (250ms ke gap par).
 */
public class AutomationVerifier {

    private static final long POLL_MS = 250;
    private static final long TIMEOUT_CONDITIONS_MS = 3500;
    private static final long TIMEOUT_DEFAULT_MS = 1500;
    private static final long TIMEOUT_LAUNCH_MS = 5000;

    public static class VerifyResult {
        public final boolean passed;
        public final String note;
        public final boolean unverified; // explicit "none" — audit mein alag dikhta hai

        VerifyResult(boolean passed, String note, boolean unverified) {
            this.passed = passed;
            this.note = note;
            this.unverified = unverified;
        }
    }

    private interface Check {
        /** null = satisfied, warna na-hone ki wajah */
        String test(AutomationObserver.ObservedState now);
    }

    public VerifyResult verify(final AutomationObserver.ObservedState before, final AutomationStep step) {
        if (step.type == AutomationStep.Type.DONE || step.type == AutomationStep.Type.FAIL) {
            return new VerifyResult(true, "no check needed", false);
        }
        if (step.recovery) {
            return new VerifyResult(true, "recovery action", false);
        }

        // 0) Step 4: non-UI steps
        if (step.type == AutomationStep.Type.WAIT) {
            return new VerifyResult(true, "waited", false);
        }
        if (step.type == AutomationStep.Type.REPLY) {
            return verifyReply(step);
        }

        // 1) Explicit post-conditions
        final List<PostCondition> conds = step.conditions;
        if (conds != null && !conds.isEmpty()) {
            boolean allNone = true;
            for (PostCondition c : conds) if (c.kind != PostCondition.Kind.NONE) allNone = false;
            if (allNone) {
                return new VerifyResult(true, "verification explicitly disabled (none)", true);
            }
            return poll(TIMEOUT_CONDITIONS_MS, new Check() {
                @Override
                public String test(AutomationObserver.ObservedState now) {
                    for (PostCondition c : conds) {
                        String why = c.check(now);
                        if (why != null) return c.kind.name().toLowerCase() + ": " + why;
                    }
                    return null;
                }
            }, "all post-conditions met");
        }

        // 2) Default per action
        switch (step.type) {
            case LAUNCH_APP: {
                final String pkg = step.packageName;
                return poll(TIMEOUT_LAUNCH_MS, new Check() {
                    @Override
                    public String test(AutomationObserver.ObservedState now) {
                        return pkg.equals(now.foregroundPackage) ? null
                                : "app not in foreground (now '" + now.foregroundPackage + "')";
                    }
                }, "app is in foreground");
            }
            case TYPE_TEXT: {
                final String typed = step.text == null ? "" : step.text.toLowerCase();
                return poll(TIMEOUT_DEFAULT_MS, new Check() {
                    @Override
                    public String test(AutomationObserver.ObservedState now) {
                        for (UiElement el : now.elements) {
                            if (el.text != null && el.text.toLowerCase().contains(typed)) return null;
                        }
                        return "typed text not visible on screen (hidden field? use '=> none' to skip)";
                    }
                }, "typed text is visible");
            }
            case SCROLL: {
                VerifyResult r = pollChange(before, TIMEOUT_DEFAULT_MS);
                return r.passed ? r : new VerifyResult(true, "screen unchanged — likely end of content", false);
            }
            case PRESS_HOME: {
                VerifyResult r = pollChange(before, TIMEOUT_DEFAULT_MS);
                return r.passed ? r : new VerifyResult(true, "screen unchanged — probably already at home", false);
            }
            case PRESS_KEY: {
                String k = step.text == null ? "" : step.text;
                if (k.equals("home")) {
                    VerifyResult r = pollChange(before, TIMEOUT_DEFAULT_MS);
                    return r.passed ? r : new VerifyResult(true, "screen unchanged — probably already at home", false);
                }
                if (k.equals("enter") || k.equals("clear")) {
                    return new VerifyResult(true, "no default check for key '" + k + "' — add '=> ...' to verify", true);
                }
                return pollChange(before, TIMEOUT_DEFAULT_MS); // back, recents, notifications, quick_settings
            }
            default:
                return pollChange(before, TIMEOUT_DEFAULT_MS); // TAP, BACK
        }
    }

    /**
     * Inline reply ka delivery confirm nahi ho sakta. Weak evidence: notification gayab ho gayi
     * ya update ho gayi (app ne reply le li). Ye bhi na mile to FAIL — par engine is step ko
     * dobara bhejta NAHI (duplicate message ka khatra), seedha escalate karta hai.
     */
    private VerifyResult verifyReply(AutomationStep step) {
        long end = System.currentTimeMillis() + 4000;
        do {
            NotificationStore.Item now = NotificationStore.get(step.notificationKey);
            if (now == null) {
                return new VerifyResult(true, "notification cleared after reply (weak evidence — delivery itself not confirmed)", false);
            }
            if (now.postTime != step.notifPostTimeBefore) {
                return new VerifyResult(true, "notification updated after reply (weak evidence — delivery itself not confirmed)", false);
            }
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        } while (System.currentTimeMillis() < end);
        return new VerifyResult(false, "notification did not change after reply — sent but not confirmed", false);
    }

    private VerifyResult pollChange(final AutomationObserver.ObservedState before, long timeoutMs) {
        return poll(timeoutMs, new Check() {
            @Override
            public String test(AutomationObserver.ObservedState now) {
                return now.looksSameAs(before) ? "screen unchanged after action" : null;
            }
        }, "screen changed");
    }

    private VerifyResult poll(long timeoutMs, Check check, String okNote) {
        long end = System.currentTimeMillis() + timeoutMs;
        String last = "not satisfied";
        do {
            AutomationObserver.ObservedState now = AutomationObserver.observe();
            if (!now.accessibilityAvailable) {
                return new VerifyResult(false, "Accessibility service not available during verify", false);
            }
            String why = check.test(now);
            if (why == null) return new VerifyResult(true, okNote, false);
            last = why;
            try {
                Thread.sleep(POLL_MS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        } while (System.currentTimeMillis() < end);
        return new VerifyResult(false, last, false);
    }
}
