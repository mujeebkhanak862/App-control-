package com.controlhub.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LogDao {

    @Insert
    void insert(LogEntity log);

    @Query("SELECT * FROM logs ORDER BY timestamp DESC LIMIT :limit")
    List<LogEntity> getRecent(int limit);

    /** Step 6: audit log ki size bound — sirf sabse naye :keep rows rakho */
    @Query("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT :keep)")
    int keepLatest(int keep);

    @Query("DELETE FROM logs WHERE timestamp < :beforeTimestamp")
    void deleteOlderThan(long beforeTimestamp);
}
