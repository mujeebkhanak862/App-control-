package com.controlhub.app.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Feature #12 — Accessibility Service class (insaan ke "aankh aur haath")
 *
 * Ye service jab tak Feature #11 ke through user manually on nahi karega,
 * ye class chalegi hi nahi — Android ka security rule hai.
 */
public class ControlHubAccessibilityService extends AccessibilityService {

    private static final String TAG = "ControlHubAccessibility";

    // Feature #12 — singleton reference, taaki baaki app (aage Stage 4 ka Local API)
    // isi chalti hui service ko call kar sake
    private static ControlHubAccessibilityService instance;

    private volatile List<UiElement> lastReadElements = new ArrayList<>();

    public static ControlHubAccessibilityService getInstance() {
        return instance;
    }

    public static boolean isRunning() {
        return instance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        Log.i(TAG, "ControlHub Accessibility Service connected");
        com.controlhub.app.events.PermissionEvents.publish("accessibility", true); // Step 7
    }

    private long lastContentEventAt = 0;

    /**
     * Step 7 — live observation: screen/app badalne par "screen.changed" event (sirf package + activity class,
     * text/content KABHI nahi). Sirf tab kaam karta hai jab koi events sun raha ho (battery bachane ke liye);
     * content-change events 1.5 sec mein ek se zyada nahi.
     */
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || com.controlhub.app.events.EventBus.connectedClients() == 0) return;
        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            publishScreenEvent("window_state", event);
        } else if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            long now = System.currentTimeMillis();
            if (now - lastContentEventAt >= 1500) {
                lastContentEventAt = now;
                publishScreenEvent("content", event);
            }
        }
    }

    private void publishScreenEvent(String kind, AccessibilityEvent e) {
        try {
            org.json.JSONObject data = new org.json.JSONObject();
            data.put("kind", kind);
            data.put("package", e.getPackageName() == null ? "" : e.getPackageName().toString());
            data.put("class", e.getClassName() == null ? "" : e.getClassName().toString());
            com.controlhub.app.events.EventBus.publish("screen.changed", data);
        } catch (org.json.JSONException ignored) {
        }
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (instance == this) {
            instance = null;
            com.controlhub.app.events.PermissionEvents.publish("accessibility", false); // Step 7
        }
    }

    // ---------------------------------------------------------------
    // Feature #13 — read_ui(): current screen ke elements padhna
    // ---------------------------------------------------------------
    // Step 3 FIX: har call NAYI list banati hai. Pehle ek hi shared list clear+refill hoti thi,
    // isliye "before" aur "after" observation asal mein same object the aur Verify hamesha
    // "screen unchanged" batata tha.
    public List<UiElement> readUi() {
        List<UiElement> result = new ArrayList<>();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Log.w(TAG, "readUi(): root window null hai — koi active screen nahi mili");
            lastReadElements = result;
            return result;
        }
        collectNodes(root, result, 0, -1);
        lastReadElements = result;
        return new ArrayList<>(result);
    }

    private void collectNodes(AccessibilityNodeInfo node, List<UiElement> out, int depth, int parentIndex) {
        if (node == null) return;

        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);

        String text = node.getText() != null ? node.getText().toString() : "";
        String className = node.getClassName() != null ? node.getClassName().toString() : "";
        String resourceId = node.getViewIdResourceName() != null ? node.getViewIdResourceName() : "";

        int myIndex = parentIndex;
        // Sirf meaningful nodes rakho (khaali/invisible nodes skip karo)
        if (!bounds.isEmpty()) {
            UiElement el = new UiElement(
                    out.size(),
                    text,
                    className,
                    resourceId,
                    node.isClickable(),
                    node.isScrollable(),
                    node.isEditable(),
                    new Rect(bounds)
            );
            el.contentDesc = node.getContentDescription() != null ? node.getContentDescription().toString() : "";
            el.packageName = node.getPackageName() != null ? node.getPackageName().toString() : "";
            el.depth = depth;
            el.parentId = parentIndex;
            el.enabled = node.isEnabled();
            el.focused = node.isFocused();
            out.add(el);
            myIndex = el.elementId;
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            collectNodes(child, out, depth + 1, myIndex);
            if (child != null) {
                child.recycle();
            }
        }
    }

    // ---------------------------------------------------------------
    // Feature #14 — tap(x, y): coordinate pe tap
    // ---------------------------------------------------------------
    public void tap(int x, int y) {
        Path path = new Path();
        path.moveTo(x, y);

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 50);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();

        dispatchGesture(gesture, null, null);
    }

    // ---------------------------------------------------------------
    // Feature #15 — tap(element_id): pichli readUi() list se element dhoondke tap
    // ---------------------------------------------------------------
    public boolean tapElement(int elementId) {
        for (UiElement el : lastReadElements) {
            if (el.elementId == elementId) {
                return clickElement(el);
            }
        }
        Log.w(TAG, "tapElement(): elementId " + elementId + " nahi mila — pehle readUi() call karo");
        return false;
    }

    // ---------------------------------------------------------------
    // Step 3 — clickElement(): pehle real node par ACTION_CLICK (clickable parent tak),
    // na ho paye to coordinate gesture (fallback)
    // ---------------------------------------------------------------
    public boolean clickElement(UiElement el) {
        if (el == null || el.bounds == null) return false;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            AccessibilityNodeInfo node = findNode(root, el);
            AccessibilityNodeInfo target = node;
            int hops = 0;
            while (target != null && !target.isClickable() && hops < 6) {
                target = target.getParent();
                hops++;
            }
            if (target != null && target.isClickable()
                    && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
        }
        tap(el.centerX(), el.centerY()); // bounded coordinate fallback
        return true;
    }

    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo n, UiElement el) {
        if (n == null) return null;
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        String rid = n.getViewIdResourceName() != null ? n.getViewIdResourceName() : "";
        String cls = n.getClassName() != null ? n.getClassName().toString() : "";
        if (b.equals(el.bounds) && rid.equals(el.resourceId) && cls.equals(el.className)) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findNode(n.getChild(i), el);
            if (r != null) return r;
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Feature #16 — type_text(): focused/editable field mein text likhna
    // ---------------------------------------------------------------
    public boolean typeText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;

        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused == null) {
            Log.w(TAG, "typeText(): koi focused input field nahi mila");
            return false;
        }

        Bundle arguments = new Bundle();
        arguments.putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);

        boolean result = focused.performAction(
                AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);

        focused.recycle();
        return result;
    }

    // ---------------------------------------------------------------
    // Feature #17 — scroll(direction): swipe gesture se scroll
    // direction: "up", "down", "left", "right"
    // ---------------------------------------------------------------
    public void scroll(String direction) {
        Rect screen = new Rect();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            root.getBoundsInScreen(screen);
        } else {
            screen.set(0, 0, 1080, 1920); // fallback, jab tak koi active window na mile
        }

        int centerX = screen.centerX();
        int centerY = screen.centerY();
        int quarterH = screen.height() / 4;
        int quarterW = screen.width() / 4;

        Path path = new Path();
        switch (direction) {
            case "down":
                path.moveTo(centerX, centerY - quarterH);
                path.lineTo(centerX, centerY + quarterH);
                break;
            case "up":
                path.moveTo(centerX, centerY + quarterH);
                path.lineTo(centerX, centerY - quarterH);
                break;
            case "left":
                path.moveTo(centerX + quarterW, centerY);
                path.lineTo(centerX - quarterW, centerY);
                break;
            case "right":
                path.moveTo(centerX - quarterW, centerY);
                path.lineTo(centerX + quarterW, centerY);
                break;
            default:
                Log.w(TAG, "scroll(): unknown direction " + direction);
                return;
        }

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 300);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(stroke)
                .build();

        dispatchGesture(gesture, null, null);
    }

    // ---------------------------------------------------------------
    // Feature #18 — system navigation buttons
    // ---------------------------------------------------------------
    public void pressBack() {
        performGlobalAction(GLOBAL_ACTION_BACK);
    }

    // ---------------------------------------------------------------
    // Step 7 — long-click, key-press, clear-text, foreground package
    // ---------------------------------------------------------------
    public boolean longTapElement(int elementId) {
        for (UiElement el : lastReadElements) {
            if (el.elementId == elementId) return longClickElement(el);
        }
        Log.w(TAG, "longTapElement(): elementId " + elementId + " nahi mila — pehle readUi() call karo");
        return false;
    }

    /** Pehle node ka ACTION_LONG_CLICK (long-clickable parent tak), na ho to ~700ms ka gesture */
    public boolean longClickElement(UiElement el) {
        if (el == null || el.bounds == null) return false;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            AccessibilityNodeInfo target = findNode(root, el);
            int hops = 0;
            while (target != null && !target.isLongClickable() && hops < 6) {
                target = target.getParent();
                hops++;
            }
            if (target != null && target.isLongClickable()
                    && target.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                return true;
            }
        }
        longPress(el.centerX(), el.centerY());
        return true;
    }

    public void longPress(int x, int y) {
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 700);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    /** Supported: back, home, recents, notifications, quick_settings, enter (Android 11+), clear */
    public boolean pressKey(String key) {
        if (key == null) return false;
        switch (key) {
            case "back": return performGlobalAction(GLOBAL_ACTION_BACK);
            case "home": return performGlobalAction(GLOBAL_ACTION_HOME);
            case "recents": return performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "notifications": return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case "quick_settings": return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
            case "enter": return pressImeEnter();
            case "clear": return typeText("");
            default: return false;
        }
    }

    private boolean pressImeEnter() {
        if (Build.VERSION.SDK_INT < 30) return false; // IME enter action Android 11+ par hi
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused == null) return false;
        return focused.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
    }

    /**
     * Rollback helper: focused input ka text EXACTLY expected ke barabar ho tabhi use khaali karta hai —
     * taaki kisi aur ka (user ka apna) text kabhi na mite.
     */
    public boolean clearFocusedInputIfEquals(String expected) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (focused == null) return false;
        CharSequence current = focused.getText();
        if (current == null || !current.toString().equals(expected)) return false;
        return typeText("");
    }

    public String getForegroundPackage() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null) return "";
        return root.getPackageName().toString();
    }

    public void pressHome() {
        performGlobalAction(GLOBAL_ACTION_HOME);
    }

    // ---------------------------------------------------------------
    // Feature #25 — Screenshot capture
    // takeScreenshot() sirf Android 11 (API 30) aur upar available hai —
    // ye Android platform ki apni limit hai, purane phones par ye feature
    // clearly "unsupported" bolega, crash nahi karega.
    // ---------------------------------------------------------------
    @RequiresApi(api = Build.VERSION_CODES.R)
    public Bitmap takeScreenshotSync(long timeoutMs) {
        final Bitmap[] resultHolder = new Bitmap[1];
        final CountDownLatch latch = new CountDownLatch(1);

        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override
            public void onSuccess(@NonNull ScreenshotResult screenshot) {
                try {
                    Bitmap hwBitmap = Bitmap.wrapHardwareBuffer(
                            screenshot.getHardwareBuffer(), screenshot.getColorSpace());
                    if (hwBitmap != null) {
                        // Hardware bitmap ko software copy mein badalte hain taaki
                        // PNG encode karna reliable rahe
                        resultHolder[0] = hwBitmap.copy(Bitmap.Config.ARGB_8888, false);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Screenshot processing failed: " + e.getMessage());
                } finally {
                    screenshot.getHardwareBuffer().close();
                    latch.countDown();
                }
            }

            @Override
            public void onFailure(int errorCode) {
                Log.w(TAG, "takeScreenshot() failed, errorCode=" + errorCode);
                latch.countDown();
            }
        });

        try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return resultHolder[0];
    }
}
