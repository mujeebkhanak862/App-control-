package com.controlhub.app.security;

import android.content.Context;

import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.LogEntity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Feature #41 — Audit Log
 * Har sensitive/actioned request ka record — kya hua, kab hua — Room ke
 * "logs" table (Feature #3, Stage 1) mein. Room main-thread query allow
 * nahi karta, isliye ek chhota background executor use karte hain.
 */
public class AuditLogger {

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    public static void log(Context context, String level, String message) {
        executor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
            db.logDao().insert(new LogEntity(message, level, System.currentTimeMillis()));
        });
    }

    public static void info(Context context, String message) {
        log(context, "info", message);
    }

    public static void warning(Context context, String message) {
        log(context, "warning", message);
    }

    public static void error(Context context, String message) {
        log(context, "error", message);
    }
}
