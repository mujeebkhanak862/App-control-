package com.controlhub.app.security;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

/**
 * Step 6 — Rate limiting + galat-token lockout (PURE JAVA, test-able).
 *
 *  - tryAcquire(key, limit, windowMs): sliding window — window mein limit se zyada request par false
 *  - Auth failures: 8 galat token / 60 sec par IP 5 minute ke liye lock (brute-force se bachav)
 */
public class RateLimiter {

    public interface Clock {
        long now();
    }

    public static final int MAX_FAILURES = 8;
    public static final long FAILURE_WINDOW_MS = 60_000;
    public static final long LOCKOUT_MS = 5 * 60_000;
    private static final int MAX_KEYS = 5000;

    private final Clock clock;
    private final Map<String, Deque<Long>> windows = new HashMap<>();
    private final Map<String, Deque<Long>> failures = new HashMap<>();
    private final Map<String, Long> lockedUntil = new HashMap<>();

    public RateLimiter() {
        this(new Clock() {
            @Override
            public long now() {
                return System.currentTimeMillis();
            }
        });
    }

    public RateLimiter(Clock clock) {
        this.clock = clock;
    }

    /** true = allowed (aur ginti mein jud gaya), false = limit paar */
    public synchronized boolean tryAcquire(String key, int limit, long windowMs) {
        long now = clock.now();
        Deque<Long> q = windows.get(key);
        if (q == null) {
            if (windows.size() >= MAX_KEYS) windows.clear(); // memory bound — worst case limits reset
            q = new ArrayDeque<>();
            windows.put(key, q);
        }
        while (!q.isEmpty() && now - q.peekFirst() >= windowMs) q.pollFirst();
        if (q.size() >= limit) return false;
        q.addLast(now);
        return true;
    }

    /** 0 = lock nahi; warna kitne ms aur lock rahega */
    public synchronized long lockedForMs(String client) {
        Long until = lockedUntil.get(client);
        if (until == null) return 0;
        long left = until - clock.now();
        if (left <= 0) {
            lockedUntil.remove(client);
            return 0;
        }
        return left;
    }

    public synchronized void recordFailure(String client) {
        long now = clock.now();
        Deque<Long> q = failures.get(client);
        if (q == null) {
            if (failures.size() >= MAX_KEYS) failures.clear();
            q = new ArrayDeque<>();
            failures.put(client, q);
        }
        while (!q.isEmpty() && now - q.peekFirst() >= FAILURE_WINDOW_MS) q.pollFirst();
        q.addLast(now);
        if (q.size() >= MAX_FAILURES) {
            lockedUntil.put(client, now + LOCKOUT_MS);
            q.clear();
        }
    }

    public synchronized void recordSuccess(String client) {
        failures.remove(client);
    }
}
