package com.controlhub.app.accessibility;

import android.graphics.Rect;

/**
 * Feature #13 — read_ui() ka ek result item.
 * Insaan jaisa "dekhna" — screen ka har element is format mein represent hota hai.
 */
public class UiElement {

    public int elementId;       // read_ui() call ke andar ka index — tap(element_id) isse match karega
    public String text;
    public String className;
    public String resourceId;
    public boolean clickable;
    public boolean scrollable;
    public boolean editable;
    public Rect bounds;

    // ---- Step 3: selector matching ke liye extra info ----
    public String contentDesc = "";   // accessibility content description
    public String packageName = "";   // is element ka app package
    public int depth = 0;             // tree mein gehrai
    public int parentId = -1;         // nearest (list mein maujood) parent ka elementId; -1 = root
    public boolean enabled = true;
    public boolean focused = false;

    public UiElement(int elementId, String text, String className, String resourceId,
                      boolean clickable, boolean scrollable, boolean editable, Rect bounds) {
        this.elementId = elementId;
        this.text = text;
        this.className = className;
        this.resourceId = resourceId;
        this.clickable = clickable;
        this.scrollable = scrollable;
        this.editable = editable;
        this.bounds = bounds;
    }

    public int centerX() {
        return bounds.centerX();
    }

    public int centerY() {
        return bounds.centerY();
    }
}
