package com.controlhub.app.adapters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Step 8 — Generic "message bhejo" adapter: search -> chat kholo -> type -> send, har step par post-condition.
 * Har app ke liye sirf selector config alag hota hai (%C = contact ka naam).
 *
 *  Mode A (background): notification inline reply  ->  reply:<pkg>|<contact>|<message>
 *  Mode B (foreground): UI flow
 *
 * HONEST: in selectors ko maine real phone par verify NAHI kiya — ye "starter" definitions hain (app ke
 * known UI naming + content-desc/text fallbacks). Apps inhe update ke saath badalte hain; pehle device test
 * mein adjust honge. Isiliye status() "starter" batata hai.
 */
public class MessagingAdapter implements AppAdapter {

    public static class Config {
        public String openSearch;      // search icon/bar kholne ke selectors
        public String searchField;     // search kholne ke baad dikhne wala input
        public String resultRow;       // search result mein contact ki row (%C = contact)
        public String chatOpened;      // chat khulne ka saboot (%C = contact)
        public String input;           // message input field
        public String send;            // send button
        public String sendGone;        // send ke baad ye element gayab hona chahiye
    }

    private final String name;
    private final String pkg;
    private final String description;
    private final Config cfg;

    public MessagingAdapter(String name, String pkg, String description, Config cfg) {
        this.name = name;
        this.pkg = pkg;
        this.description = description;
        this.cfg = cfg;
    }

    @Override public String name() { return name; }
    @Override public String packageName() { return pkg; }
    @Override public String description() { return description; }
    @Override public int version() { return 1; }
    @Override public String status() { return "starter (selectors not yet verified on a real device)"; }
    @Override public List<String> actions() { return Arrays.asList("send_message"); }

    @Override
    public boolean supportsBackground(String action) {
        return "send_message".equals(action);
    }

    @Override
    public List<String> expand(String action, String[] args, boolean background) {
        if (!"send_message".equals(action)) {
            throw new IllegalArgumentException("Unknown " + name + " action: " + action + " (supported: send_message)");
        }
        if (args.length < 2 || args[0].trim().isEmpty() || args[1].isEmpty()) {
            throw new IllegalArgumentException("send_message needs: do:" + name + ".send_message|<contact>|<message>");
        }
        String contact = args[0].trim();
        String message = args[1];

        List<String> out = new ArrayList<>();
        if (background) {
            out.add("reply:" + pkg + "|" + contact + "|" + message);
            return out;
        }
        out.add("open:" + pkg + " => pkg:" + pkg);
        out.add("tap:" + cfg.openSearch + " => appears:" + cfg.searchField);
        out.add("type:" + contact);
        out.add("tap:" + cfg.resultRow.replace("%C", contact) + " => appears:" + cfg.chatOpened.replace("%C", contact));
        out.add("tap:" + cfg.input + " => appears:" + cfg.input);
        out.add("type:" + message);
        out.add("tap:" + cfg.send + " => gone:" + cfg.sendGone + " && text:" + message);
        return out;
    }

    // ---------------- ready-made starter configs ----------------

    public static MessagingAdapter telegram() {
        Config c = new Config();
        c.openSearch = "desc=Search";
        c.searchField = "cls=EditText";
        c.resultRow = "cls=TextView & has=%C";
        c.chatOpened = "desc=Attach media || desc=Attach || desc=Record voice message || desc=Voice message";
        c.input = "cls=EditText";
        c.send = "desc=Send";
        c.sendGone = "desc=Send";
        return new MessagingAdapter("telegram", "org.telegram.messenger",
                "Send a Telegram message (inline reply if possible, else UI automation)", c);
    }

    public static MessagingAdapter instagram() {
        Config c = new Config();
        c.openSearch = "desc=Search || id=action_bar_search_edit_text";
        c.searchField = "cls=EditText";
        c.resultRow = "id=row_inbox_username & has=%C || cls=TextView & has=%C";
        c.chatOpened = "id=row_thread_composer_edittext || cls=EditText & has=Message";
        c.input = "id=row_thread_composer_edittext || cls=EditText";
        c.send = "id=row_thread_composer_send_button || text=Send || desc=Send";
        c.sendGone = "text=Send || id=row_thread_composer_send_button";
        return new MessagingAdapter("instagram", "com.instagram.android",
                "Send an Instagram direct message (inline reply if possible, else UI automation)", c);
    }

    public static MessagingAdapter messenger() {
        Config c = new Config();
        c.openSearch = "desc=Search || text=Search";
        c.searchField = "cls=EditText";
        c.resultRow = "cls=TextView & has=%C";
        c.chatOpened = "desc=Send || desc=Choose a sticker || cls=EditText & has=Message";
        c.input = "cls=EditText";
        c.send = "desc=Send || id=send_button";
        c.sendGone = "desc=Send";
        return new MessagingAdapter("messenger", "com.facebook.orca",
                "Send a Messenger message (inline reply if possible, else UI automation)", c);
    }

    public static MessagingAdapter signal() {
        Config c = new Config();
        c.openSearch = "desc=Search || id=search_view";
        c.searchField = "cls=EditText";
        c.resultRow = "id=contact_name & has=%C || cls=TextView & has=%C";
        c.chatOpened = "id=embedded_text_editor || id=conversation_title & has=%C";
        c.input = "id=embedded_text_editor || cls=EditText";
        c.send = "id=send_button || desc=Send";
        c.sendGone = "id=send_button";
        return new MessagingAdapter("signal", "org.thoughtcrime.securesms",
                "Send a Signal message (inline reply if possible, else UI automation)", c);
    }
}
