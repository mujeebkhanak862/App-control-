package com.controlhub.app.automation;

import com.controlhub.app.adapters.AdapterRegistry;
import com.controlhub.app.adapters.AppAdapter;
import com.controlhub.app.notifications.NotificationStore;

import java.util.ArrayList;
import java.util.List;

/**
 * Step 4 — Task banate waqt instructions ko "compile" karta hai:
 *   1) do:<adapter>.<action>|arg1|arg2  ko asli commands mein badalta hai
 *   2) Mode chunta hai:
 *        background = sirf notification-reply / wait (screen par kuch nahi)
 *        foreground = UI automation (Mode B) — isko user ki explicit allowForeground:true chahiye
 *        auto       = adapter background support kare AUR reply-able notification maujood ho to
 *                     background, warna foreground
 *   3) Saari commands validate karta hai (galat syntax yahin pakda jata hai)
 *
 * Nateeja DB mein expand ho chuki instructions ke roop mein save hota hai, taaki resume ke waqt
 * checkpoint index hamesha sahi commands se match kare.
 */
public class InstructionCompiler {

    public static class Result {
        public String instructions;    // expand ho chuki (nayi line se alag)
        public String modeUsed;        // "background" | "foreground"
        public boolean needsForeground;
    }

    public static Result compile(String instructions, String requestedMode) {
        String mode = requestedMode == null ? "auto" : requestedMode.trim().toLowerCase();
        if (!(mode.equals("auto") || mode.equals("background") || mode.equals("foreground"))) {
            throw new IllegalArgumentException("mode must be auto, background or foreground");
        }

        List<String> expanded = new ArrayList<>();
        for (String raw : AutomationReasoner.parseCommands(instructions)) {
            if (raw.startsWith("do:")) {
                expanded.addAll(expandAdapterCommand(raw, mode));
            } else {
                expanded.add(raw);
            }
        }
        if (expanded.isEmpty()) throw new IllegalArgumentException("No commands");

        // Sab commands parse karke validate karo
        boolean needsForeground = false;
        for (String c : expanded) {
            AutomationCommand cmd = AutomationCommand.parse(c);
            if (cmd.isUi()) needsForeground = true;
        }

        if (mode.equals("background") && needsForeground) {
            throw new IllegalArgumentException(
                    "background mode cannot run UI commands (open/tap/type/scroll/back/home) — use mode=foreground or auto");
        }

        Result r = new Result();
        StringBuilder joined = new StringBuilder();
        for (int i = 0; i < expanded.size(); i++) {
            if (i > 0) joined.append('\n');
            joined.append(expanded.get(i));
        }
        r.instructions = joined.toString();
        r.needsForeground = needsForeground;
        r.modeUsed = needsForeground ? "foreground" : "background";
        return r;
    }

    private static final String[] FORBIDDEN_IN_VALUES = {"\n", "\r", ";;", " => ", " && ", " || ", " & "};

    private static void checkValue(String label, String v) {
        for (String bad : FORBIDDEN_IN_VALUES) {
            if (v.contains(bad)) {
                throw new IllegalArgumentException(label + " cannot contain a newline or the separators ';;', ' => ', ' && ', ' || ', ' & '");
            }
        }
    }

    private static List<String> expandAdapterCommand(String raw, String mode) {
        String body = raw.substring("do:".length());
        String[] parts = body.split("\\|", 3);       // <adapter>.<action> | arg1 | arg2 (baaki sab arg2)
        String head = parts[0].trim();
        int dot = head.indexOf('.');
        if (dot <= 0 || dot == head.length() - 1) {
            throw new IllegalArgumentException("Use do:<adapter>.<action>|args — got: " + head);
        }
        String adapterName = head.substring(0, dot);
        String action = head.substring(dot + 1);
        AppAdapter adapter = AdapterRegistry.get(adapterName);
        if (adapter == null) {
            throw new IllegalArgumentException("Unknown adapter: " + adapterName);
        }
        if (!adapter.actions().contains(action)) {
            throw new IllegalArgumentException("Adapter " + adapterName + " has no action '" + action + "'");
        }

        String[] args = new String[parts.length - 1];
        for (int i = 1; i < parts.length; i++) {
            args[i - 1] = parts[i];
            checkValue("argument " + i, parts[i]);
        }

        boolean background;
        if (mode.equals("background")) {
            if (!adapter.supportsBackground(action)) {
                throw new IllegalArgumentException(adapterName + "." + action + " has no background (Mode A) version");
            }
            background = true;
        } else if (mode.equals("foreground")) {
            background = false;
        } else { // auto
            background = adapter.supportsBackground(action)
                    && args.length > 0
                    && NotificationStore.findReplyable(adapter.packageName(), args[0].trim()) != null;
        }
        return adapter.expand(action, args, background);
    }
}
