package com.controlhub.app.sdk;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

/**
 * Feature #57 — Developer SDK: registered modules ka registry.
 * LocalApiServer "/x/<module>/<capability>" requests yahin se resolve karta hai.
 */
public final class CapabilityRegistry {

    private static final Pattern NAME = Pattern.compile("^[a-z][a-z0-9_]{1,31}$");
    // TreeMap = manifest mein stable (alphabetical) order
    private static final Map<String, CapabilityModule> modules = new TreeMap<>();

    private CapabilityRegistry() {
    }

    public static final class Resolved {
        public final CapabilityModule module;
        public final Capability capability;

        Resolved(CapabilityModule module, Capability capability) {
            this.module = module;
            this.capability = capability;
        }
    }

    /**
     * Module register karta hai.
     * @return true = naya register hua; false = is naam ka module pehle se registered hai (kuch nahi badla)
     * @throws IllegalArgumentException naam/capabilities galat hon
     */
    public static synchronized boolean register(CapabilityModule module) {
        if (module == null) throw new IllegalArgumentException("module is null");
        String moduleName = module.name();
        if (moduleName == null || !NAME.matcher(moduleName).matches()) {
            throw new IllegalArgumentException("Invalid module name: " + moduleName
                    + " (use a-z, 0-9, _ ; start with a letter ; 2-32 chars)");
        }

        List<Capability> caps = module.capabilities();
        if (caps == null || caps.isEmpty()) {
            throw new IllegalArgumentException("Module '" + moduleName + "' has no capabilities");
        }
        Set<String> seen = new HashSet<>();
        for (Capability c : caps) {
            if (c == null || c.name == null || !NAME.matcher(c.name).matches()) {
                throw new IllegalArgumentException("Invalid capability name in module '" + moduleName + "'");
            }
            if (c.handler == null || c.scope == null) {
                throw new IllegalArgumentException("Capability '" + c.name + "' needs a scope and a handler");
            }
            if (!seen.add(c.name)) {
                throw new IllegalArgumentException("Duplicate capability '" + c.name + "' in module '" + moduleName + "'");
            }
        }

        if (modules.containsKey(moduleName)) {
            return false;
        }
        modules.put(moduleName, module);
        return true;
    }

    public static synchronized boolean unregister(String moduleName) {
        return modules.remove(moduleName) != null;
    }

    public static synchronized boolean isRegistered(String moduleName) {
        return modules.containsKey(moduleName);
    }

    /** "/x/<module>/<capability>" -> Resolved, ya null (galat format / naam nahi mila) */
    public static synchronized Resolved resolve(String uri) {
        if (uri == null || !uri.startsWith("/x/")) return null;
        String[] parts = uri.substring(3).split("/", -1);
        if (parts.length != 2) return null;

        CapabilityModule m = modules.get(parts[0]);
        if (m == null) return null;
        for (Capability c : m.capabilities()) {
            if (c.name.equals(parts[1])) {
                return new Resolved(m, c);
            }
        }
        return null;
    }

    /** /capabilities manifest ke liye: saare modules ka description */
    public static synchronized JSONArray describeAll() {
        JSONArray out = new JSONArray();
        try {
            for (CapabilityModule m : modules.values()) {
                JSONObject mo = new JSONObject();
                mo.put("module", m.name());
                mo.put("version", m.version());
                JSONArray caps = new JSONArray();
                for (Capability c : m.capabilities()) {
                    JSONObject co = new JSONObject();
                    co.put("name", c.name);
                    co.put("path", "/x/" + m.name() + "/" + c.name);
                    co.put("method", "POST");
                    co.put("scope", c.scope.name());
                    co.put("description", c.description);
                    JSONArray args = new JSONArray();
                    for (Capability.Arg a : c.args) {
                        JSONObject ao = new JSONObject();
                        ao.put("name", a.name);
                        ao.put("type", a.type.name().toLowerCase());
                        ao.put("required", a.required);
                        ao.put("description", a.description);
                        args.put(ao);
                    }
                    co.put("arguments", args);
                    caps.put(co);
                }
                mo.put("capabilities", caps);
                out.put(mo);
            }
        } catch (JSONException e) {
            // keys hardcoded/non-null hain — practically nahi hota
        }
        return out;
    }
}
