package com.controlhub.app.connectors;

import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Feature #58 — Connector layer ke safety rules (pure Java, Android par depend nahi karta).
 *
 * Webhook connector phone se bahar HTTP POST karta hai. Is liye teen cheezein zaroori hain:
 *  1. Sirf HTTPS, aur destination ghar ke andar ka (localhost / LAN / cloud-metadata) na ho
 *     — warna ye connector phone ke local network par requests bhejne ka rasta ban sakta hai.
 *  2. Kaunse events bahar jaayenge (default: sirf task.complete + error)
 *  3. Rate limit — ek loop ya spam se webhook ko flood na kare
 */
public final class WebhookPolicy {

    private WebhookPolicy() {
    }

    private static final Set<String> DEFAULT_EVENTS = Collections.unmodifiableSet(
            new HashSet<>(Arrays.asList("task.complete", "error")));

    private static final int MAX_URL_LENGTH = 2000;

    /** @return null agar URL theek hai, warna user ko dikhane layak error message */
    public static String validateUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            return "URL is empty";
        }
        String url = raw.trim();
        if (url.length() > MAX_URL_LENGTH) {
            return "URL is too long";
        }

        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            return "URL is not valid";
        }

        if (uri.getScheme() == null || !uri.getScheme().equalsIgnoreCase("https")) {
            return "Only https:// URLs are allowed";
        }
        if (uri.getUserInfo() != null) {
            return "URLs with user:password@ are not allowed";
        }

        String host = uri.getHost();
        if (host == null || host.isEmpty()) {
            return "URL has no host";
        }
        String h = host.toLowerCase(Locale.ROOT);
        if (h.startsWith("[") && h.endsWith("]")) {
            h = h.substring(1, h.length() - 1);
        }

        if (h.equals("localhost") || h.endsWith(".localhost") || h.endsWith(".local")
                || h.endsWith(".internal") || h.endsWith(".lan") || h.endsWith(".home")) {
            return "Local/internal host names are not allowed";
        }

        // Agar host seedha IP literal hai to yahin check ho jaata hai (DNS ki zaroorat nahi).
        // Naam wale hosts ka asli IP send ke waqt resolve karke check hota hai (isBlockedAddress).
        if (looksLikeIpLiteral(h)) {
            try {
                InetAddress a = InetAddress.getByName(h);   // literal hai, DNS lookup nahi hota
                if (isBlockedAddress(a)) {
                    return "Private / local IP addresses are not allowed";
                }
            } catch (Exception e) {
                return "URL host is not valid";
            }
        }
        return null;
    }

    private static boolean looksLikeIpLiteral(String h) {
        if (h.indexOf(':') >= 0) return true;   // IPv6
        String[] parts = h.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String p : parts) {
            if (p.isEmpty()) return false;
            for (int i = 0; i < p.length(); i++) {
                if (!Character.isDigit(p.charAt(i))) return false;
            }
        }
        return true;
    }

    /** Loopback / LAN / link-local (cloud metadata 169.254.x.x) / CGNAT / ULA / multicast — sab blocked */
    public static boolean isBlockedAddress(InetAddress a) {
        if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress()
                || a.isSiteLocalAddress() || a.isMulticastAddress()) {
            return true;
        }
        byte[] b = a.getAddress();
        if (b.length == 4) {
            int b0 = b[0] & 0xFF;
            int b1 = b[1] & 0xFF;
            if (b0 == 0) return true;                          // 0.0.0.0/8
            if (b0 == 100 && b1 >= 64 && b1 <= 127) return true; // 100.64.0.0/10 (CGNAT)
        } else if (b.length == 16) {
            if ((b[0] & 0xFE) == 0xFC) return true;            // fc00::/7 (IPv6 unique-local)
        }
        return false;
    }

    /** Kaunsa event bahar jaana chahiye */
    public static boolean shouldForward(String eventType, boolean forwardAll) {
        if (eventType == null) return false;
        return forwardAll || DEFAULT_EVENTS.contains(eventType);
    }

    /** Sliding-window rate limiter: ek minute mein max N sends. Clock bahar se aata hai (testable). */
    public static final class RateLimiter {
        private final int maxPerWindow;
        private final long windowMs;
        private final ArrayDeque<Long> stamps = new ArrayDeque<>();

        public RateLimiter(int maxPerWindow, long windowMs) {
            this.maxPerWindow = maxPerWindow;
            this.windowMs = windowMs;
        }

        public synchronized boolean tryAcquire(long nowMs) {
            while (!stamps.isEmpty() && nowMs - stamps.peekFirst() >= windowMs) {
                stamps.pollFirst();
            }
            if (stamps.size() >= maxPerWindow) {
                return false;
            }
            stamps.addLast(nowMs);
            return true;
        }
    }
}
