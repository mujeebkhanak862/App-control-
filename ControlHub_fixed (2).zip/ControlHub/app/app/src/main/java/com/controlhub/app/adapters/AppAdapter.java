package com.controlhub.app.adapters;

import java.util.List;

/**
 * Step 4 — App adapter: kisi app ke kaam (jaise "message bhejo") ko Control Hub ki
 * commands (selectors + post-conditions) mein badalta hai.
 */
public interface AppAdapter {
    String name();
    String packageName();
    String description();
    int version();
    /** "starter" = device par verify nahi hua; selectors app version ke saath badal sakte hain */
    String status();
    List<String> actions();
    /** Kya ye action notification inline-reply (Mode A, background) se ho sakta hai */
    boolean supportsBackground(String action);
    /** @throws IllegalArgumentException galat action/args par */
    List<String> expand(String action, String[] args, boolean background);
}
