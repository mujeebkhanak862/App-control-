package com.controlhub.app.apkhost;

import android.content.Context;
import android.net.Uri;

/**
 * Feature #44-47 (Stage 9) + Feature #48-49 (Stage 10) — ek jagah tied together.
 * Future mein (Local API ya Nex Integration) isi facade ko call karega, poore
 * subsystem ke internal parts ko alag-alag jaanne ki zaroorat nahi hogi.
 */
public class ApkHostFacade {

    private final RuntimeAdapter runtimeAdapter = new ExternalLaunchRuntimeAdapter();

    /** Feature #44/#45 — import + registry */
    public ApkImportManager.ImportResult importApk(Context context, Uri apkFileUri) {
        return ApkImportManager.importApk(context, apkFileUri);
    }

    /** Feature #48 — compatibility check (device SDK + already-installed check) */
    public boolean isCompatible(Context context, HostedApkEntity apk) {
        boolean sdkOk = ExternalLaunchRuntimeAdapter.isDeviceSdkSupported(apk.minSdkVersion);
        boolean runtimeOk = runtimeAdapter.isSupported(context, apk);
        return sdkOk && runtimeOk;
    }

    /** Feature #46/#49 — session start + honest launch attempt */
    public RuntimeAdapter.LaunchResult launch(Context context, HostedApkEntity apk) {
        if (!ExternalLaunchRuntimeAdapter.isDeviceSdkSupported(apk.minSdkVersion)) {
            return new RuntimeAdapter.LaunchResult(false, false,
                    "This APK needs Android API " + apk.minSdkVersion +
                            ", this device is API " + android.os.Build.VERSION.SDK_INT);
        }

        HostSessionManager.Session session = HostSessionManager.startSession(context, apk.packageName);
        RuntimeAdapter.LaunchResult result = runtimeAdapter.launch(context, apk);

        if (!result.launched) {
            HostSessionManager.endSession(context, session.sessionId);
        }
        return result;
    }
}
