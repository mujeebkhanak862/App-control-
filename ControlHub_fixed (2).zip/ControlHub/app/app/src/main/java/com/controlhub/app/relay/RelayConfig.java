package com.controlhub.app.relay;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/**
 * Feature #55 — Relay ki settings (backend ka URL + device token)
 *
 * Device token ek secret hai (jo backend ke DEVICE_TOKEN se match hona chahiye),
 * isliye ApiTokenManager ki tarah EncryptedSharedPreferences mein rakha hai.
 * ApiTokenManager se ek farq: agar encrypted storage bane hi nahi, to yahan
 * plaintext par girte NAHI — relay "not configured" maana jaata hai (secret ko
 * chupchaap plain file mein likhne se behtar hai ki feature band rahe).
 */
public class RelayConfig {

    private static final String TAG = "RelayConfig";
    private static final String PREFS_NAME = "control_hub_relay_prefs_encrypted";
    private static final String KEY_URL = "relay_url";
    private static final String KEY_TOKEN = "device_token";

    private static SharedPreferences prefs(Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            return EncryptedSharedPreferences.create(
                    context, PREFS_NAME, masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            Log.e(TAG, "Encrypted storage unavailable — relay config disabled", e);
            return null;
        }
    }

    public static String getUrl(Context context) {
        SharedPreferences p = prefs(context);
        return p == null ? "" : p.getString(KEY_URL, "");
    }

    public static String getDeviceToken(Context context) {
        SharedPreferences p = prefs(context);
        return p == null ? "" : p.getString(KEY_TOKEN, "");
    }

    public static boolean isConfigured(Context context) {
        return !getUrl(context).isEmpty() && !getDeviceToken(context).isEmpty();
    }

    /**
     * Save karta hai. URL blank + token blank = relay band (config clear).
     * @return null agar save ho gaya, warna error message (user ko dikhane ke liye)
     */
    public static String save(Context context, String rawUrl, String rawToken) {
        SharedPreferences p = prefs(context);
        if (p == null) {
            return "Encrypted storage is not available on this device";
        }

        String url = rawUrl == null ? "" : rawUrl.trim();
        String token = rawToken == null ? "" : rawToken.trim();

        if (url.isEmpty() && token.isEmpty()) {
            p.edit().remove(KEY_URL).remove(KEY_TOKEN).apply();
            return null;
        }

        String normalized = normalizeUrl(url);
        if (normalized == null) {
            return "URL must start with wss:// or https:// (plain ws:// / http:// is blocked for safety)";
        }
        if (token.length() < 24) {
            return "Device token is too short (use at least 24 characters)";
        }

        p.edit().putString(KEY_URL, normalized).putString(KEY_TOKEN, token).apply();
        return null;
    }

    /**
     * https://app.up.railway.app      -> wss://app.up.railway.app/device
     * wss://app.up.railway.app/device -> as is
     * http:// / ws:// / kuch aur      -> null (reject)
     */
    static String normalizeUrl(String url) {
        String lower = url.toLowerCase();
        String rest;
        if (lower.startsWith("https://")) {
            rest = url.substring("https://".length());
        } else if (lower.startsWith("wss://")) {
            rest = url.substring("wss://".length());
        } else {
            return null;
        }
        if (rest.isEmpty() || rest.startsWith("/") || rest.contains(" ")) {
            return null;
        }
        if (!rest.contains("/") || rest.endsWith("/")) {
            rest = (rest.endsWith("/") ? rest : rest + "/") + "device";
        }
        return "wss://" + rest;
    }
}
