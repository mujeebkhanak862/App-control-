package com.controlhub.app.apkhost;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface HostedApkDao {

    @Insert
    long insert(HostedApkEntity apk);

    @Update
    void update(HostedApkEntity apk);

    @Query("SELECT * FROM hosted_apks ORDER BY importedAt DESC")
    List<HostedApkEntity> getAll();

    @Query("SELECT * FROM hosted_apks WHERE packageName = :packageName ORDER BY importedAt DESC LIMIT 1")
    HostedApkEntity getLatestByPackage(String packageName);

    @Query("SELECT * FROM hosted_apks WHERE id = :id LIMIT 1")
    HostedApkEntity getById(long id);
}
